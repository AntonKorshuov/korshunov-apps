const https = require('https');
const fs = require('fs');
const path = require('path');
const { app } = require('electron');

const MANIFEST_URL = 'https://raw.githubusercontent.com/AntonKorshuov/korshunov-apps/main/mathe-champion/version.json';

// Helper to compare semver '1.0.1' > '1.0.0'
function isNewerVersion(remote, local) {
  const rParts = remote.split('.').map(n => parseInt(n, 10) || 0);
  const lParts = local.split('.').map(n => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(rParts.length, lParts.length); i++) {
    const r = rParts[i] || 0;
    const l = lParts[i] || 0;
    if (r > l) return true;
    if (r < l) return false;
  }
  return false;
}

function fetchJson(url) {
  return new Promise((resolve, reject) => {
    const reqUrl = `${url}?t=${Date.now()}`;
    https.get(reqUrl, { headers: { 'User-Agent': 'MatheChampion-Client' } }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return fetchJson(res.headers.location).then(resolve).catch(reject);
      }
      if (res.statusCode !== 200) {
        return reject(new Error(`HTTP ${res.statusCode}`));
      }
      let raw = '';
      res.on('data', chunk => raw += chunk);
      res.on('end', () => {
        try {
          resolve(JSON.parse(raw));
        } catch (e) {
          reject(e);
        }
      });
    }).on('error', reject);
  });
}

function downloadFile(url, destPath) {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(destPath);
    https.get(url, { headers: { 'User-Agent': 'MatheChampion-Client' } }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        file.close();
        fs.unlinkSync(destPath);
        return downloadFile(res.headers.location, destPath).then(resolve).catch(reject);
      }
      if (res.statusCode !== 200) {
        file.close();
        fs.unlinkSync(destPath);
        return reject(new Error(`Download failed with HTTP ${res.statusCode}`));
      }
      res.pipe(file);
      file.on('finish', () => {
        file.close(() => resolve(destPath));
      });
    }).on('error', (err) => {
      file.close();
      try { fs.unlinkSync(destPath); } catch {}
      reject(err);
    });
  });
}

class RemoteUpdater {
  constructor() {
    this.currentVersion = app.getVersion();
  }

  async checkForUpdates() {
    try {
      const manifest = await fetchJson(MANIFEST_URL);
      if (manifest && manifest.version && isNewerVersion(manifest.version, this.currentVersion)) {
        return {
          hasUpdate: true,
          version: manifest.version,
          description: manifest.description || 'Neues Mathe-Update verfügbar',
          downloadUrl: manifest.downloadUrl || 'https://raw.githubusercontent.com/AntonKorshuov/korshunov-apps/main/mathe-champion/update-bundle.zip'
        };
      }
      return { hasUpdate: false, currentVersion: this.currentVersion };
    } catch (err) {
      console.log('Update check failed (likely offline):', err.message);
      return { hasUpdate: false, error: err.message };
    }
  }

  async downloadAndApplyUpdate(downloadUrl, onProgress) {
    try {
      const tempZip = path.join(app.getPath('temp'), `mathe-update-${Date.now()}.zip`);
      await downloadFile(downloadUrl, tempZip);

      // Extract zip using PowerShell Expand-Archive (built-in on Windows, zero external deps!)
      const targetDir = path.join(__dirname, '..'); // app root directory
      const { exec } = require('child_process');
      const cmd = `powershell.exe -NoProfile -Command "Expand-Archive -Path '${tempZip}' -DestinationPath '${targetDir}' -Force; Remove-Item '${tempZip}' -Force"`;

      return new Promise((resolve, reject) => {
        exec(cmd, (error) => {
          if (error) {
            return reject(error);
          }
          resolve({ success: true });
        });
      });
    } catch (err) {
      console.error('Apply update failed:', err);
      throw err;
    }
  }
}

module.exports = { RemoteUpdater };
